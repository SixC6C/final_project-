<?php
include_once('connect.php');
session_start();

$dbs = new database();
$db = $dbs->connection();

// Helper: Safe escape function
function escape($db, $str) {
    return mysqli_real_escape_string($db, trim($str));
}

// Only allow logged-in users (optional security)
if (!isset($_SESSION['User'])) {
    die("Access denied.");
}

// ======================= CITY ADD / EDIT =======================
if (isset($_POST['cityy'])) {
    $cityid = isset($_GET['cityedit']) ? (int)$_GET['cityedit'] : 0;
    $stateid = (int)$_POST['state'];
    $cityname = escape($db, $_POST['city']);

    if ($cityid > 0) {
        // EDIT CITY
        $check = mysqli_query($db, "SELECT CityId FROM city WHERE CityId = '$cityid'");
        if (mysqli_num_rows($check) > 0) {
            mysqli_query($db, "UPDATE city SET StateId = '$stateid', Name = '$cityname' WHERE CityId = '$cityid'");
        }
    } else {
        // ADD NEW CITY
        mysqli_query($db, "INSERT INTO city (StateId, Name) VALUES ('$stateid', '$cityname')");
    }
    header("Location: ../city.php");
    exit;
}

// ======================= STATE ADD / EDIT =======================
else if (isset($_POST['addstates'])) {
    $stateid = isset($_GET['stateedit']) ? (int)$_GET['stateedit'] : 0;
    $countryid = (int)$_POST['country'];
    $statename = escape($db, $_POST['state']);

    if ($stateid > 0) {
        $check = mysqli_query($db, "SELECT StateId FROM state WHERE StateId = '$stateid'");
        if (mysqli_num_rows($check) > 0) {
            mysqli_query($db, "UPDATE state SET CountryId = '$countryid', Name = '$statename' WHERE StateId = '$stateid'");
        }
    } else {
        mysqli_query($db, "INSERT INTO state (CountryId, Name) VALUES ('$countryid', '$statename')");
    }
    header("Location: ../state.php");
    exit;
}

// ======================= COUNTRY ADD / EDIT =======================
else if (isset($_POST['countryy'])) {
    $countryid = isset($_GET['countryedit']) ? (int)$_GET['countryedit'] : 0;
    $countryname = escape($db, $_POST['country']);

    if ($countryid > 0) {
        $check = mysqli_query($db, "SELECT CountryId FROM country WHERE CountryId = '$countryid'");
        if (mysqli_num_rows($check) > 0) {
            mysqli_query($db, "UPDATE country SET Name = '$countryname' WHERE CountryId = '$countryid'");
        }
    } else {
        mysqli_query($db, "INSERT INTO country (Name) VALUES ('$countryname')");
    }
    header("Location: ../country.php");
    exit;
}

// ======================= POSITION ADD / EDIT =======================
else if (isset($_POST['positionl'])) {
    $positionid = isset($_GET['positionedit']) ? (int)$_GET['positionedit'] : 0;
    $positionname = escape($db, $_POST['position']);

    if ($positionid > 0) {
        $check = mysqli_query($db, "SELECT PositinId FROM position WHERE PositinId = '$positionid'");
        if (mysqli_num_rows($check) > 0) {
            mysqli_query($db, "UPDATE position SET Name = '$positionname' WHERE PositinId = '$positionid'");
        }
    } else {
        mysqli_query($db, "INSERT INTO position (Name) VALUES ('$positionname')");
    }
    header("Location: ../position.php");
    exit;
}

// ======================= DELETE OPERATIONS =======================
else if (isset($_GET['statedelete'])) {
    $id = (int)$_GET['statedelete'];
    mysqli_query($db, "DELETE FROM state WHERE StateId = '$id'");
    header("Location: ../state.php");
    exit;
}
else if (isset($_GET['citydelete'])) {
    $id = (int)$_GET['citydelete'];
    // Optional: Prevent deleting city if used in employee table
    mysqli_query($db, "DELETE FROM city WHERE CityId = '$id'");
    header("Location: ../city.php");
    exit;
}
else if (isset($_GET['countrydelete'])) {
    $id = (int)$_GET['countrydelete'];
    // Be careful: deleting country will break states/cities
    mysqli_query($db, "DELETE FROM country WHERE CountryId = '$id'");
    header("Location: ../country.php");
    exit;
}
else if (isset($_GET['positiondelete'])) {
    $id = (int)$_GET['positiondelete'];
    mysqli_query($db, "DELETE FROM position WHERE PositinId = '$id'");
    header("Location: ../position.php");
    exit;
}

// If someone accesses this file directly without POST/GET
else {
    echo "<script>alert('Invalid access!'); window.location='../Home.php';</script>";
    exit;
}
?>