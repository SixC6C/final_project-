<?php include('header.php'); ?>
<?php
	include_once('controller/connect.php');
	$dbs = new database();
	$db = $dbs->connection();

	$page = "";
	$SearchName = $_GET['search'] ?? '';

	if (!empty($SearchName)) {
		$SearchName = mysqli_real_escape_string($db, $SearchName);
		$RecordeLimit = 10;

		// Count total matching records
		$countQuery = mysqli_query($db, "SELECT COUNT(EmpId) AS total FROM employee 
			WHERE RoleId != '1' 
			AND (FirstName LIKE '%$SearchName%' 
			  OR MiddleName LIKE '%$SearchName%' 
			  OR LastName LIKE '%$SearchName%' 
			  OR EmployeeId LIKE '%$SearchName%')");
		$totalRows = mysqli_fetch_assoc($countQuery)['total'];
		$number_of_pages = ceil($totalRows / $RecordeLimit);

		$pageNo = max(1, (int)($_GET['bn'] ?? 1));
		if ($pageNo > $number_of_pages) $pageNo = $number_of_pages;
		$offset = ($pageNo - 1) * $RecordeLimit;

		$sql = mysqli_query($db, "SELECT * FROM employee 
			WHERE RoleId != '1' 
			AND (FirstName LIKE '%$SearchName%' 
			  OR MiddleName LIKE '%$SearchName%' 
			  OR LastName LIKE '%$SearchName%' 
			  OR EmployeeId LIKE '%$SearchName%') 
			LIMIT $offset, $RecordeLimit");
	} else {
		$RecordeLimit = 10;
		$countQuery = mysqli_query($db, "SELECT COUNT(EmpId) AS total FROM employee WHERE RoleId != '1'");
		$totalRows = mysqli_fetch_assoc($countQuery)['total'];
		$number_of_pages = ceil($totalRows / $RecordeLimit);

		$pageNo = max(1, (int)($_GET['bn'] ?? 1));
		if ($pageNo > $number_of_pages) $pageNo = $number_of_pages;
		$offset = ($pageNo - 1) * $RecordeLimit;

		$sql = mysqli_query($db, "SELECT * FROM employee WHERE RoleId != '1' LIMIT $offset, $RecordeLimit");
	}

	// Pagination links
	for ($i = 1; $i <= $number_of_pages; $i++) {
		$active = ($i == $pageNo) ? 'style="background:#667eea;color:white;"' : '';
		if (!empty($SearchName)) {
			$page .= "<a href='?search=$SearchName&bn=$i' class='page-btn' $active>$i</a> ";
		} else {
			$page .= "<a href='?bn=$i' class='page-btn' $active>$i</a> ";
		}
	}
?>
<style>
	/* Modern Table Card Style */
	.table-card {
		background: white;
		border-radius: 16px;
		box-shadow: 0 10px 30px rgba(0,0,0,0.08);
		overflow: hidden;
		margin: 20px 0;
	}

	.table-header {
		background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
		color: white;
		padding: 20px 30px;
		font-size: 1.5rem;
		font-weight: 600;
	}

	.search-box {
		position: relative;
		max-width: 400px;
		margin-left: auto;
	}

	.search-box input {
		width: 100%;
		padding: 12px 50px 12px 20px;
		border: 2px solid #e2e8f0;
		border-radius: 12px;
		font-size: 1rem;
		transition: all 0.3s;
	}

	.search-box input:focus {
		border-color: #667eea;
		box-shadow: 0 0 0 4px rgba(102,126,234,0.1);
		outline: none;
	}

	.search-box button {
		position: absolute;
		right: 5px;
		top: 50%;
		transform: translateY(-50%);
		background: #667eea;
		color: white;
		border: none;
		width: 40px;
		height: 40px;
		border-radius: 10px;
		cursor: pointer;
	}

	.employee-row {
		transition: all 0.3s ease;
		border-bottom: 1px solid #f1f5f9;
	}

	.employee-row:hover {
		background: #f8fafc;
		transform: translateY(-2px);
		box-shadow: 0 5px 15px rgba(0,0,0,0.05);
	}

	.profile-img {
		width: 60px;
		height: 60px;
		object-fit: cover;
		border-radius: 50%;
		border: 3px solid #e2e8f0;
		transition: all 0.3s;
	}

	.profile-img:hover {
		transform: scale(1.1);
		border-color: #667eea;
	}

	.name {
		font-weight: 600;
		color: #2d3748;
		font-size: 1.1rem;
	}

	.emp-id {
		background: #edf2f7;
		color: #4a5568;
		padding: 6px 14px;
		border-radius: 30px;
		font-weight: 500;
		font-size: 0.9rem;
		display: inline-block;
	}

	.view-btn {
		background: linear-gradient(135deg, #667eea, #764ba2);
		color: white;
		padding: 8px 20px;
		border-radius: 30px;
		text-decoration: none;
		font-weight: 500;
		transition: all 0.3s;
		display: inline-block;
	}

	.view-btn:hover {
		transform: translateY(-3px);
		box-shadow: 0 10px 20px rgba(102,126,234,0.3);
		color: white;
		text-decoration: none;
	}

	.pagination {
		text-align: center;
		margin: 30px 0;
	}

	.page-btn {
		display: inline-block;
		margin: 0 5px;
		padding: 10px 16px;
		background: #f1f5f9;
		color: #64748b;
		border-radius: 10px;
		text-decoration: none;
		font-weight: 500;
		transition: all 0.3s;
	}

	.page-btn:hover, .page-btn[style*="background"] {
		background: #667eea;
		color: white;
		transform: translateY(-2px);
	}

	@media (max-width: 768px) {
		.table-header {
			font-size: 1.3rem;
			text-align: center;
		}
		.search-box {
			max-width: 100%;
			margin: 15px 0;
		}
	}
</style>

<!-- Breadcrumb -->
<ol class="breadcrumb" style="margin: 15px 0; font-size: 14px;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a> → Employee → Employee List</li>
</ol>

<!-- Modern Employee Table Card -->
<div class="container-fluid">
	<div class="table-card">
		<div class="table-header d-flex justify-content-between align-items-center flex-wrap">
			<div>Employee Directory</div>
			<form method="GET" class="search-box">
				<input type="text" name="search" placeholder="Search by name or ID..." 
					   value="<?php echo htmlspecialchars($SearchName); ?>">
				<button type="submit"><i class="fa fa-search"></i></button>
			</form>
		</div>

		<div class="table-responsive" style="padding: 20px;">
			<table class="table table-borderless">
				<tbody>
					<?php while ($row = mysqli_fetch_assoc($sql)): 
						$fullName = trim(ucfirst($row['FirstName']) . ' ' . $row['MiddleName'] . ' ' . $row['LastName']);
						$photo = !empty($row['ImageName']) ? 'image/' . $row['ImageName'] : 'image/default-avatar.png';
					?>
					<tr class="employee-row align-middle">
						<td style="width:100px;">
							<img src="<?php echo $photo; ?>" alt="<?php echo htmlspecialchars($fullName); ?>" class="profile-img">
						</td>
						<td>
							<div class="name"><?php echo htmlspecialchars($fullName); ?></div>
						</td>
						<td>
							<span class="emp-id"><?php echo htmlspecialchars($row['EmployeeId']); ?></span>
						</td>
						<td class="text-end">
							<a href="detailview.php?employeeid=<?php echo $row['EmpId']; ?>" class="view-btn">
								View Profile
							</a>
						</td>
					</tr>
					<?php endwhile; ?>

					<?php if (mysqli_num_rows($sql) == 0): ?>
					<tr>
						<td colspan="4" class="text-center py-5 text-muted">
							<i class="fa fa-users fa-3x mb-3"></i><br>
							No employees found
						</td>
					</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>

		<!-- Pagination -->
		<?php if ($number_of_pages > 1): ?>
		<div class="pagination">
			<?php echo $page; ?>
		</div>
		<?php endif; ?>
	</div>
</div>

<!-- Optional: Add default avatar if image missing -->
<style>
	img[src=""] { content: url('image/default-avatar.png'); }
</style>

<?php include('footer.php'); ?>