<?php include('header.php');?>
<?php
  include_once('controller/connect.php');
  $dbs = new database();
  $db = $dbs->connection();

  $Statusl = "Pending";
  $leavedetails = mysqli_query($db, "SELECT l.*, e.FirstName, e.LastName, lt.Type_of_Name FROM leavedetails l JOIN employee e ON l.EmpId=e.EmployeeId JOIN type_of_leave lt ON l.TypesLeaveId=lt.LeaveId WHERE l.LeaveStatus='".$Statusl."'");

  if(isset($_GET['id']))
  {
    $acceptid = $_GET['id'];
    $accept = "Accept";
    mysqli_query($db,"update leavedetails set LeaveStatus='$accept' where Detail_Id='$acceptid'");
    echo "<script>window.location='leaverequest.php';</script>";
  }
  else if(isset($_GET['msg']))
  {
    $deniedid = $_GET['msg'];
    $denied = "Denied";
    mysqli_query($db,"update leavedetails set LeaveStatus='$denied' where Detail_Id='$deniedid'");
    echo "<script>window.location='leaverequest.php';</script>";
  }

  $laccept = mysqli_query($db,"SELECT l.*,e.FirstName,e.LastName,lt.Type_of_Name FROM leavedetails l JOIN employee e ON l.EmpId=e.EmployeeId JOIN type_of_leave lt on l.TypesLeaveId=lt.LeaveId WHERE LeaveStatus='Accept'");
  $ldenied = mysqli_query($db,"SELECT l.*,e.FirstName,e.LastName,lt.Type_of_Name FROM leavedetails l JOIN employee e ON l.EmpId=e.EmployeeId JOIN type_of_leave lt on l.TypesLeaveId=lt.LeaveId WHERE LeaveStatus='Denied'");
?>
<style>
    :root {
        --primary: #667eea;
        --primary-light: #764ba2;
        --success: #10b981;
        --danger: #ef4444;
        --warning: #f59e0b;
        --gray-100: #f8fafc;
        --gray-200: #e2e8f0;
        --gray-600: #475569;
        --gray-800: #1e293b;
        --shadow: 0 20px 25px -5px rgba(0,0,0,0.1);
    }
    body { background: var(--gray-100); font-family: 'Segoe UI', sans-serif; }

    .page-header {
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
        color: white;
        padding: 30px;
        border-radius: 20px;
        margin: 20px 0;
        box-shadow: var(--shadow);
        text-align: center;
    }
    .page-header h2 {
        font-size: 2.5rem;
        font-weight: 800;
        margin: 0;
    }

    .leave-card {
        background: white;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        margin-bottom: 30px;
        transition: all 0.4s;
    }
    .leave-card:hover { transform: translateY(-8px); box-shadow: 0 20px 40px rgba(0,0,0,0.15); }

    .card-title {
        background: linear-gradient(135deg, #1e293b, #334155);
        color: white;
        padding: 20px 30px;
        font-size: 1.5rem;
        font-weight: 700;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .card-title i { font-size: 1.8rem; }

    .pending-title   { background: linear-gradient(135deg, #f59e0b, #ea580c); }
    .accepted-title  { background: linear-gradient(135deg, #10b981, #059669); }
    .denied-title    { background: linear-gradient(135deg, #ef4444, #dc2626); }

    .leave-row {
        padding: 18px 30px;
        border-bottom: 1px solid #f1f5f9;
        display: flex;
        align-items: center;
        transition: all 0.3s;
    }
    .leave-row:hover {
        background: #f8fafc;
        transform: translateX(8px);
    }
    .leave-row:last-child { border-bottom: none; }

    .col-id     { flex: 0.5; font-weight: 700; color: var(--primary); }
    .col-name   { flex: 2; font-weight: 600; color: var(--gray-800); }
    .col-empid  { flex: 1; text-align: center; }
    .col-type   { flex: 1.5; }
    .col-reason { flex: 1.2; font-style: italic; color: var(--gray-600); }
    .col-date   { flex: 1.2; text-align: center; font-weight: 500; }
    .col-action { flex: 1; text-align: center; }

    .btn-accept, .btn-deny {
        padding: 10px 18px;
        border-radius: 50px;
        font-weight: 600;
        text-decoration: none;
        display: inline-block;
        transition: all 0.3s;
        width: 80px;
    }
    .btn-accept {
        background: #10b981;
        color: white;
    }
    .btn-accept:hover {
        background: #059669;
        transform: translateY(-3px);
        box-shadow: 0 10px 20px rgba(16,185,129,0.3);
    }
    .btn-deny {
        background: #ef4444;
        color: white;
    }
    .btn-deny:hover {
        background: #dc2626;
        transform: translateY(-3px);
        box-shadow: 0 10px 20px rgba(239,68,68,0.3);
    }

    .status-badge {
        padding: 6px 16px;
        border-radius: 50px;
        font-size: 0.85rem;
        font-weight: 600;
        display: inline-block;
    }
    .status-pending  { background: #fff7ed; color: #c2410c; }
    .status-accepted { background: #ecfdf5; color: #047857; }
    .status-denied   { background: #fee2e2; color: #991b1b; }

    @media (max-width: 992px) {
        .leave-row {
            flex-direction: column;
            text-align: center;
            padding: 20px;
            gap: 10px;
        }
        .col-id, .col-name, .col-empid, .col-type, .col-reason, .col-date, .col-action {
            flex: none !important;
        }
        .page-header h2 { font-size: 2rem; }
    }
</style>

<!-- Breadcrumb -->
<ol class="breadcrumb" style="margin: 15px 0; font-size: 14px;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a> → Leave → Leave Requests</li>
</ol>

<div class="container-fluid" style="padding: 0 20px; max-width: 1600px; margin: 0 auto;">

    <!-- Pending Requests -->
    <div class="leave-card">
        <div class="card-title pending-title">
            <i class="fa fa-clock-o"></i> Pending Leave Requests
        </div>
        <?php $i=1; while($row = mysqli_fetch_assoc($leavedetails)) {
            $first = $row['FirstName'] ?? '';
            $last = $row['LastName'] ?? '';
            $namem = ucfirst($first)." ".ucfirst($last);
        ?>
        <div class="leave-row">
            <div class="col-id">#<?php echo $i++; ?></div>
            <div class="col-name"><?php echo htmlspecialchars($namem); ?></div>
            <div class="col-empid"><?php echo $row['EmpId']; ?></div>
            <div class="col-type"><span class="status-badge status-pending"><?php echo ucfirst($row['Type_of_Name']); ?></span></div>
            <div class="col-reason"><?php echo ucfirst($row['Reason'] ?? 'No reason'); ?></div>
            <div class="col-date"><?php echo date('d M Y', strtotime($row['StateDate'])); ?></div>
            <div class="col-date"><?php echo date('d M Y', strtotime($row['EndDate'])); ?></div>
            <div class="col-action">
                <a href="?id=<?php echo $row['Detail_Id'];?>" class="btn-accept" title="Accept">
                    <i class="fa fa-check"></i> Accept
                </a>
                <a href="?msg=<?php echo $row['Detail_Id'];?>" class="btn-deny" title="Deny">
                    <i class="fa fa-times"></i> Deny
                </a>
            </div>
        </div>
        <?php } ?>
        <?php if(mysqli_num_rows($leavedetails) == 0): ?>
        <div class="leave-row text-center text-muted" style="padding: 50px; color: #94a3b8;">
            <i class="fa fa-check-circle fa-3x mb-3"></i><br>
            No pending leave requests
        </div>
        <?php endif; mysqli_data_seek($leavedetails, 0); ?>
    </div>

    <!-- Accepted Leaves -->
    <div class="leave-card">
        <div class="card-title accepted-title">
            <i class="fa fa-check-circle"></i> Approved Leaves
        </div>
        <?php $i=1; while($row = mysqli_fetch_assoc($laccept)) { 
            $name = ucfirst($row['FirstName']." ".$row['LastName']);
        ?>
        <div class="leave-row">
            <div class="col-id">#<?php echo $i++; ?></div>
            <div class="col-name"><?php echo htmlspecialchars($name); ?></div>
            <div class="col-type"><span class="status-badge status-accepted"><?php echo $row['Type_of_Name']; ?></span></div>
            <div class="col-date"><?php echo date('d M Y', strtotime($row['StateDate'])); ?></div>
            <div class="col-date"><?php echo date('d M Y', strtotime($row['EndDate'])); ?></div>
        </div>
        <?php } ?>
        <?php if(mysqli_num_rows($laccept) == 0): ?>
        <div class="leave-row text-center text-muted" style="padding: 50px; color: #94a3b8;">
            <i class="fa fa-ban fa-3x mb-3"></i><br>
            No approved leaves
        </div>
        <?php endif; ?>
    </div>

    <!-- Denied Leaves -->
    <div class="leave-card">
        <div class="card-title denied-title">
            <i class="fa fa-times-circle"></i> Denied Leaves
        </div>
        <?php $i=1; while($row = mysqli_fetch_assoc($ldenied)) {
            $name = ucfirst($row['FirstName']." ".$row['LastName']);
        ?>
        <div class="leave-row">
            <div class="col-id">#<?php echo $i++; ?></div>
            <div class="col-name"><?php echo htmlspecialchars($name); ?></div>
            <div class="col-type"><span class="status-badge status-denied"><?php echo $row['Type_of_Name']; ?></span></div>
            <div class="col-date"><?php echo date('d M Y', strtotime($row['StateDate'])); ?></div>
            <div class="col-date"><?php echo date('d M Y', strtotime($row['EndDate'])); ?></div>
        </div>
        <?php } ?>
        <?php if(mysqli_num_rows($ldenied) == 0): ?>
        <div class="leave-row text-center text-muted" style="padding: 50px; color: #94a3b8;">
            <i class="fa fa-thumbs-up fa-3x mb-3"></i><br>
            No denied requests
        </div>
        <?php endif; ?>
    </div>

</div>

<?php include('footer.php'); ?>