<?php include('header.php'); ?>
<?php
  include_once('controller/connect.php');
  $dbs = new database();
  $db = $dbs->connection();

  $TotalEmp = mysqli_query($db, "SELECT COUNT(EmployeeId) AS emp FROM employee WHERE RoleId != '1'");
  $TotalEmploId = mysqli_fetch_assoc($TotalEmp);

  $pandingleave = mysqli_query($db, "SELECT COUNT(LeaveStatus) AS pleave FROM leavedetails WHERE LeaveStatus='Pending'");
  $tpandingleave = mysqli_fetch_assoc($pandingleave);
?>

<!-- Breadcrumb -->
<ol class="breadcrumb" style="margin: 15px 0; font-size: 14px;">
    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
</ol>

<!-- Modern Dashboard Cards -->
<div class="row" style="padding: 0 15px;">
    
    <!-- Total Employees Card -->
    <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
        <a href="employeeview.php" style="text-decoration:none; color:inherit;">
            <div class="card shadow-sm border-0 hover-shadow" style="border-radius:12px; overflow:hidden; transition: all 0.3s ease;">
                <div class="card-body text-white" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px;">
                    <div class="d-flex align-items-center">
                        <div class="icon-circle me-4" style="background:rgba(255,255,255,0.2); width:70px; height:70px; border-radius:50%; display:flex; align-items:center; justify-content:center;">
                            <i class="fa fa-users fa-2x"></i>
                        </div>
                        <div>
                            <h5 class="mb-1 text-white opacity-90">Total Employees</h5>
                            <h2 class="mb-0 fw-bold"><?php echo $TotalEmploId['emp'] ?? '0'; ?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>

    <!-- Pending Leave Requests Card -->
    <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
        <a href="leaverequest.php" style="text-decoration:none; color:inherit;">
            <div class="card shadow-sm border-0 hover-shadow" style="border-radius:12px; overflow:hidden; transition: all 0.3s ease;">
                <div class="card-body text-white" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); padding: 30px;">
                    <div class="d-flex align-items-center">
                        <div class="icon-circle me-4" style="background:rgba(255,255,255,0.2); width:70px; height:70px; border-radius:50%; display:flex; align-items:center; justify-content:center;">
                            <i class="fa fa-calendar-times-o fa-2x"></i>
                        </div>
                        <div>
                            <h5 class="mb-1 text-white opacity-90">Pending Leave Requests</h5>
                            <h2 class="mb-0 fw-bold"><?php echo $tpandingleave['pleave'] ?? '0'; ?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>

</div>

<!-- Optional Extra Cards (Uncomment if you want more) -->
<!--
<div class="row" style="padding: 0 15px;">
    <div class="col-lg-6 col-md-6 mb-4">
        <div class="card border-0 shadow-sm" style="border-radius:12px;">
            <div class="card-body text-success" style="background: linear-gradient(135deg, #84fab0 0%, #8fd3f4 100%);">
                <h5>Active Projects</h5>
                <h2>24</h2>
            </div>
        </div>
    </div>
    <div class="col-lg-6 col-md-6 mb-4">
        <div class="card border-0 shadow-sm" style="border-radius:12px;">
            <div class="card-body text-warning" style="background: linear-gradient(135deg, #ffd89b 0%, #19547b 100%);">
                <h5>Today's Attendance</h5>
                <h2>89%</h2>
            </div>
        </div>
    </div>
</div>
-->

<style>
    .hover-shadow:hover {
        transform: translateY(-8px);
        box-shadow: 0 15px 35px rgba(0,0,0,0.15) !important;
    }
    .card-body h5 {
        font-size: 1.1rem;
        font-weight: 500;
        letter-spacing: 0.5px;
    }
    .card-body h2 {
        font-size: 2.8rem;
        font-weight: 700;
    }
    .icon-circle i {
        filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
    }
    @media (max-width: 768px) {
        .card-body {
            padding: 20px !important;
        }
        .card-body h2 {
            font-size: 2.2rem !important;
        }
    }
</style>

<?php include('footer.php'); ?>